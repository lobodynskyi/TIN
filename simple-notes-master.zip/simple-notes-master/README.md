#required
NodeJS and MongoDB need to be installed on your PC or laptop.

#steps to install 
Please go to folder where you have clone this repo, and run below commands
- npm install

#start server
Once installation is complete 
- run mongodb server using "mongod" command
- run "node app.js" comment in another cmd
- now you can request "localhost:3333" using your browser
